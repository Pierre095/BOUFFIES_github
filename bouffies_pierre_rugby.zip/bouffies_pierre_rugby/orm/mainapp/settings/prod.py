from .base import *

DEBUG = False

ALLOWED_HOSTS = [
    "www.rugbytropicalcup.com"
]
