from django.views.generic import TemplateView



class MoreView(TemplateView):
    template_name = "more.html"