# Pour chaque fichier de vue, il faut en importer toutes les variables ici
from .home import *
from .about import *
from .stadiums import *
from .newsletter import *
from .update import *
from .teams import *
from .more import *
from .view import *
